/**
 * options.js
 * 設定ページのロジック
 */

// 設定をフォームから取得し、保存する
function saveOptions() {
  const gridSize = document.getElementById('gridSize').value;
  const lineWidth = document.getElementById('lineWidth').value;
  const lineColor = document.getElementById('lineColor').value;
  const lineStyle = document.getElementById('lineStyle').value;
  const labelFontSize = document.getElementById('labelFontSize').value;
  const labelOpacity = document.getElementById('labelOpacity').value;
  // ▼▼▼ 追加 ▼▼▼
  const labelColor = document.getElementById('labelColor').value;
  // ▲▲▲ 追加 ▲▲▲

  chrome.storage.sync.set({
    gridSize: Number(gridSize),
    lineWidth: Number(lineWidth),
    lineColor: lineColor,
    lineStyle: lineStyle,
    labelFontSize: Number(labelFontSize),
    labelOpacity: Number(labelOpacity),
    // ▼▼▼ 追加 ▼▼▼
    labelColor: labelColor
    // ▲▲▲ 追加 ▲▲▲
  }, () => {
    // 保存完了メッセージを表示
    const status = document.getElementById('status');
    status.textContent = '設定を保存しました。';
    setTimeout(() => {
      status.textContent = '';
    }, 1500);
  });
}

// 保存された設定を読み込み、フォームに反映する
function restoreOptions() {
  // デフォルト値を設定
  chrome.storage.sync.get({
    gridSize: 100,
    lineWidth: 1,
    lineColor: '#000000',
    lineStyle: 'solid',
    labelFontSize: 14,
    labelOpacity: 0.8,
    // ▼▼▼ 追加 ▼▼▼
    labelColor: '#000000'
    // ▲▲▲ 追加 ▲▲▲
  }, (items) => {
    document.getElementById('gridSize').value = items.gridSize;
    document.getElementById('lineWidth').value = items.lineWidth;
    document.getElementById('lineColor').value = items.lineColor;
    document.getElementById('lineStyle').value = items.lineStyle;
    document.getElementById('labelFontSize').value = items.labelFontSize;
    document.getElementById('labelOpacity').value = items.labelOpacity;
    document.getElementById('labelOpacityValue').textContent = items.labelOpacity;
    // ▼▼▼ 追加 ▼▼▼
    document.getElementById('labelColor').value = items.labelColor;
    // ▲▲▲ 追加 ▲▲▲
  });
}

// イベントリスナーを設定
document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);

// 不透明度スライダーの値をリアルタイムで表示する処理
const opacitySlider = document.getElementById('labelOpacity');
const opacityValue = document.getElementById('labelOpacityValue');
opacitySlider.addEventListener('input', () => {
  opacityValue.textContent = opacitySlider.value;
});