/**
 * content.js
 * Webページに挿入され、グリッドの描画と制御を行う
 */

let gridVisible = false;
let gridContainer = null;
const GRID_ID = 'transparent-grid-kun-container';

// 設定のデフォルト値と、読み込み後の値を保持するオブジェクト
let gridSettings = {
  gridSize: 100,
  lineWidth: 1,
  lineColor: '#000000',
  lineStyle: 'solid',
  labelFontSize: 14,
  labelOpacity: 0.8,
  // ▼▼▼ 追加 ▼▼▼
  labelColor: '#000000'
  // ▲▲▲ 追加 ▲▲▲
};

/**
 * グリッドとCanvasを初期化し、描画する
 */
function createAndDrawGrid() {
  // 既にコンテナが存在する場合は再描画のみ
  if (!gridContainer) {
    gridContainer = document.createElement('div');
    gridContainer.id = GRID_ID;
    const canvas = document.createElement('canvas');
    gridContainer.appendChild(canvas);
    document.body.appendChild(gridContainer);
    window.addEventListener('resize', redrawCanvas);
  }

  redrawCanvas();
  gridContainer.style.display = 'block';
  gridVisible = true;
}

/**
 * グリッドを非表示にする
 */
function hideGrid() {
  if (gridContainer) {
    gridContainer.style.display = 'none';
  }
  gridVisible = false;
}

/**
 * Canvasにグリッドを再描画する
 */
function redrawCanvas() {
  if (!gridContainer) return;

  const canvas = gridContainer.querySelector('canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const width = window.innerWidth;
  const height = window.innerHeight;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  ctx.scale(dpr, dpr);

  ctx.clearRect(0, 0, width, height);

  // --- 設定を反映 ---
  ctx.strokeStyle = gridSettings.lineColor;
  ctx.lineWidth = gridSettings.lineWidth;

  // 線の種類を設定
  if (gridSettings.lineStyle === 'dashed') {
    ctx.setLineDash([5, 5]);
  } else if (gridSettings.lineStyle === 'dotted') {
    // 線の太さに応じて点線の間隔を調整
    const dotSize = gridSettings.lineWidth;
    ctx.setLineDash([dotSize, dotSize * 2]);
  } else { // solid
    ctx.setLineDash([]);
  }
  // --- 設定の反映ここまで ---


  // ▼▼▼ 変更: 設定値からラベルのスタイルを動的に生成 ▼▼▼
  // 16進数カラーコード(#RRGGBB)をrgba形式に変換
  const hex = gridSettings.labelColor.replace('#', '');
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);

  ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${gridSettings.labelOpacity})`;
  ctx.font = `${gridSettings.labelFontSize}px Arial`;
  // ▲▲▲ 変更 ▲▲▲

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  const gridSize = Number(gridSettings.gridSize);
  if (gridSize <= 0) return; // 0以下なら描画しない

  // 縦線とアルファベット (列番号)
  for (let x = gridSize; x < width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x + 0.5, 0);
    ctx.lineTo(x + 0.5, height);
    ctx.stroke();

    const colLabel = String.fromCharCode(64 + (x / gridSize));
    ctx.fillText(colLabel, x - (gridSize / 2), gridSettings.labelFontSize);
  }

  // 横線と数字 (行番号)
  for (let y = gridSize; y < height; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, y + 0.5);
    ctx.lineTo(width, y + 0.5);
    ctx.stroke();

    const rowLabel = (y / gridSize).toString();
    ctx.fillText(rowLabel, gridSettings.labelFontSize, y - (gridSize / 2));
  }
}

// background.js からのメッセージを受け取るリスナー
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggleGrid") {
    if (gridVisible) {
      hideGrid();
    } else {
      // 表示する前に最新の設定を読み込む
      chrome.storage.sync.get(gridSettings, (items) => {
        gridSettings = items;
        createAndDrawGrid();
      });
    }
  }
});

// 設定変更を監視し、表示中であればリアルタイムに反映するリスナー
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync') {
    let settingsChanged = false;
    for (let key in changes) {
      if (gridSettings.hasOwnProperty(key)) {
        gridSettings[key] = changes[key].newValue;
        settingsChanged = true;
      }
    }
    if (settingsChanged && gridVisible) {
      redrawCanvas();
    }
  }
});