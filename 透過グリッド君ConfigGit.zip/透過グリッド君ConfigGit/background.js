/**
 * background.js
 * 拡張機能のアイコンがクリックされたときの処理
 */

// 拡張機能がインストールされたとき、または更新されたときにデフォルト設定を保存
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    gridSize: 100,
    lineWidth: 1,
    lineColor: '#000000',
    lineStyle: 'solid',
    labelFontSize: 14,
    labelOpacity: 0.8,
    labelColor: '#000000'
  });
});

// ▼▼▼ ここから修正 ▼▼▼
// 拡張機能のアイコン（Action）がクリックされたときに発火
// コールバック関数を async にして、Promiseベースのエラー処理を可能にする
chrome.action.onClicked.addListener(async (tab) => {
  // 念のため、タブIDが存在するか確認
  if (tab.id) {
    try {
      // アクティブなタブの content.js へメッセージを送信
      await chrome.tabs.sendMessage(tab.id, {
        action: "toggleGrid"
      });
    } catch (e) {
      // content scriptが注入されていないページでアイコンをクリックした場合、
      // ここでエラーが捕捉されるため、コンソールには表示されない。
      // エラーメッセージが想定通りのものか一応確認する。
      if (e.message.includes('Could not establish connection')) {
        // 想定内のエラーなので何もしない
      } else {
        // 想定外のエラーの場合はコンソールに出力する
        console.error(e);
      }
    }
  }
});
// ▲▲▲ ここまで修正 ▲▲▲